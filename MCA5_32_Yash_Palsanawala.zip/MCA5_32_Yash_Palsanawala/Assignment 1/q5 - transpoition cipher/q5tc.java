
import java.util.*;
import java.io.*;

public class q5tc
{
	public static String sarr[]={"A","OX","CAT","FOUR","MOUSE","HONEST","ACQUIRE","MEGABUCK"};
	public static void main(String args[])throws IOException
	{
		ArrayList<String> tc=arrlist();
		String es=encrypt(tc);
		System.out.println("Encrypted Text: "+es);
		String ds=decrypt(es);
		System.out.println("Decrypted Text: "+ds);
	}
	
	public static String cunt(String s)
	{
		char mn=122;
		String c=s;
		int mni=0,cc=1,size=s.length();
		for(int i=0;i<size;i++)
		{
			mn=90;
			for(int j=0;j<s.length();j++)
			{
				if(mn>s.charAt(j) && s.charAt(j)!='$')
				{
					mn=s.charAt(j);
					mni=j;
				}
			}
			s=s.replaceFirst(s.charAt(mni)+"","\\$");
			c=c.replaceFirst(c.charAt(mni)+"",cc+"");
			cc++;
		}
		return c;
	}
	public static ArrayList<String> arrlist()throws IOException
	{
		Scanner sc=new Scanner(System.in);
		ArrayList<String> tc=new ArrayList<String>();
		String s=sarr[(new Random().nextInt(sarr.length))];		
		tc.add(s);
		//System.out.println(tc);
		String c=cunt(s);
		tc.add(c);
		BufferedWriter bw=new BufferedWriter(new FileWriter("key.txt"));
		bw.write(s+"\n");
		bw.write(c);
		bw.close();
		//System.out.println(tc);
		int k=0;
		char ch='a';
		System.out.print("\nEnter text: ");
		String ss=((sc.nextLine()).replaceAll(" ","\\$"))+"$";
		int size=ss.length();
		while(k<size)
		{
			String s1="";
			for(int i=0; i<s.length(); i++)
			{
				if(k<size && ss.charAt(k)!=0)
				{
					s1=s1+ss.charAt(k);
					k++;
				}
				else
				{
					s1=s1+ch;
					ch++;					
				}
			}
			tc.add(s1);
		}
		return tc;
	}
	
	public static String encrypt(ArrayList<String> tc)
	{
		int tcc=1;
		String es="";
		for(int i=0; i<tc.get(0).length();i++)
		{
			int inn=(tc.get(1)).indexOf(tcc+"");
			tcc++;
			for(int j=2;j<tc.size();j++)
			{
				es=es+tc.get(j).charAt(inn);
			}
		}	
		return es;
	}
	
	public static String decrypt(String ens)throws IOException
	{
		BufferedReader br=new BufferedReader(new FileReader("key.txt"));
		String t;
		ArrayList<String> tc=new ArrayList<>();
		while((t=br.readLine())!=null)
		{
			tc.add(t);
		}
		System.out.println(tc.get(0));
		int tcc=1,size=ens.length()/tc.get(0).length();
		String sarr[]=new String[size];
		
		String ds="";
		while(!ens.isEmpty())
		{
			tc.add(tcc+ens.substring(0,size));
			ens=ens.substring(size);
			tcc++;
		}	
		tcc=1;
		String tt=tc.get(1);
		// for(int i=0;i<tc.get(0).length();i++)
		// {
			while(!tt.isEmpty())
			{
				char a=tt.charAt(0);
				for(int j=2;j<tc.size();j++)
				{
					if(a==tc.get(j).charAt(0))
					{
						String st=tc.get(j).substring(1);
						for(int z=0;z<st.length();z++)
						{
							if(sarr[z]==null)
							{
								sarr[z]="";
							}
							sarr[z]=sarr[z]+st.charAt(z);
						}
						if(tt.length()>=2)
						{
							tt=tt.substring(1);
						}
						else
						{
							tt="";
						}
						break;
					}
				}
			}
		// }
		for(int i=0;i<sarr.length;i++)
		{
			if(i==(sarr.length-1))
			{
				ds=ds+(sarr[i]).split("\\$")[0];
				continue;
			}			
			ds=ds+sarr[i];
		}
		ds=ds.replaceAll("\\$"," ");
		return ds;
	}
}