
public class receiver
{
 public static void main(String args[])throws Exception
 {
  
  OneTimePad obj = new OneTimePad();
  MySocket m = new MySocket();
  String encryptedString=m.receiveFrame();
  String decryptedString=obj.doDecryption(encryptedString);
  System.out.println("\nDecryted String : "+decryptedString);  
 }
}