
/*A code from www.bipinrupadiya.com*/
public class sender
{
 public static void main(String args[])throws Exception
 {
  
  String myString="Faizan Shaikh";
  /*
  // read data from user 
  Scanner sc=new Scanner(System.in);
  System.out.println("Enter String(only alphabets allowed) :");
  myString=sc.next();
  
  */
  
  OneTimePad obj = new OneTimePad();
  String encryptedString=obj.doEncryption(myString);
  System.out.println("\nEncryted String : "+encryptedString);
  MySocket m = new MySocket();
  m.sendFrame(encryptedString);
 }

}
