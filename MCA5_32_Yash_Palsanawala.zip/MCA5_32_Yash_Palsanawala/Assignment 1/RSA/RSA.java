import java.security.*;
import javax.crypto.*;
import javax.crypto.spec.*;
class RSA
{
 public KeyPairGenerator keygenerator;
 public KeyPair myKey;
 Cipher c;
 public RSA() throws Exception
 { 
  // Genrate the Key
  keygenerator = KeyPairGenerator.getInstance("RSA");
  keygenerator.initialize(1024) ;
  myKey = keygenerator.generateKeyPair();



  // Create the cipher
  c = Cipher.getInstance("RSA");
  

 }
 public byte[] doEncryption(String s) throws Exception
 {
   
      // Initialize the cipher for encryption
      c.init(Cipher.ENCRYPT_MODE,myKey.getPublic());
    
   //sensitive information
      byte[] text = s.getBytes();

   // Encrypt the text
      byte[] textEncrypted = c.doFinal(text);

   return(textEncrypted);
 }
 public String doDecryption(byte[] s)throws Exception
 {
 
      // Initialize the same cipher for decryption
   c.init(Cipher.DECRYPT_MODE,myKey.getPrivate());

      // Decrypt the text
      byte[] textDecrypted = c.doFinal(s);

   return(new String(textDecrypted));
 }
}