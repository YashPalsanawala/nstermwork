import java.util.*;
import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;

public class q3_ccudpclient
{
	public static void main(String args[]) throws IOException
	{
		Scanner sc=new Scanner(System.in);
		DatagramSocket ds=new DatagramSocket();
		InetAddress ip=InetAddress.getLocalHost();
		byte buf[]=null;
		String s;
		System.out.println("Enter String to be Encrypted: ");
		s=sc.nextLine();
		String es=encrypt(s);
		buf=es.getBytes();
		DatagramPacket dp=new DatagramPacket(buf,buf.length,ip,1234);
		ds.send(dp);
		System.out.println("Encrypted Text: "+es+" successfully sent!");
	}
	
	public static String encrypt(String s)
	{
		StringBuilder sb=new StringBuilder();
		char c;
		for(int i=0; i<s.length(); i++)
		{
			if((s.charAt(i)>='a' && s.charAt(i)<='z') || (s.charAt(i)>='A' && s.charAt(i)<='Z'))
			{
				if(s.charAt(i)<='c' && s.charAt(i)>=97)
				{
					c=(char)(s.charAt(i)+23);
					sb.append(c);
					continue;					
				}
				else if(s.charAt(i)<='C')
				{
					c=(char)(s.charAt(i)+23);
					sb.append(c);
					continue;
				}
				c=(char)(s.charAt(i)-3);
				sb.append(c);
				continue;
			}
			else if(s.charAt(i)>='0' && s.charAt(i)<='9')
			{
				if(s.charAt(i)<='2')
				{
					c=(char)(s.charAt(i)+7);
					sb.append(c);
					continue;					
				}
				c=(char)(s.charAt(i)-3);
				sb.append(c);
				continue;
			}
			sb.append(s.charAt(i));
		}
		return sb.toString();
	}
}
